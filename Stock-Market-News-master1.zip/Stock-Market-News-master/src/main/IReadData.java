package main;

import java.util.List;

public interface IReadData {
    public List<String> readData(String fileName);
}
